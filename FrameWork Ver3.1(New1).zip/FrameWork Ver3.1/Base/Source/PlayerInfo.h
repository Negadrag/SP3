#ifndef PLAYER_INFO_H
#define PLAYER_INFO_H

class PlayerInfo
{
public:
	PlayerInfo();
	~PlayerInfo();

	int i_health;
	int i_currency;

	void Init();


private:

protected:


};

#endif